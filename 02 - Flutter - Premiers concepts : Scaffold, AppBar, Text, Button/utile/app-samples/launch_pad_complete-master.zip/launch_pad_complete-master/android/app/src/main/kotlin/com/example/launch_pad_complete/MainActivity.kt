package com.example.launch_pad_complete

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
