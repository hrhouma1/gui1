import 'package:ecommerce_admin_web_panel/providers/admin_web_panel_provider.dart';
import 'package:ecommerce_admin_web_panel/views/categories/categories_page.dart';
import 'package:ecommerce_admin_web_panel/views/dashboard_page.dart';
import 'package:ecommerce_admin_web_panel/views/promoBanner/update_promo_banner_page.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'views/promoBanner/promos_banners_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: const FirebaseOptions(
        apiKey: "AIzaSyD8UXJ3eotLkOHWVnK1Bt0wLm3eYk9M3Tg",

        authDomain: "snapshopecommerceapp.firebaseapp.com",

        projectId: "snapshopecommerceapp",

        storageBucket: "snapshopecommerceapp.firebasestorage.app",

        messagingSenderId: "259127193977",

        appId: "1:259127193977:web:39d34508c154c65d5f7fa8",

        measurementId: "G-714VNF5JHB"
    )
  );

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => AdminWenPanelProvider(),
      child: MaterialApp(
        title: 'Flutter Demo',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        ),
        routes: {
          "/": (context) => DashboardPage(),
          "/promos_banners": (context) => PromosBannersPage(),
          "/update_promo_banner": (context) => const UpdatePromoBannerPage(),
          "/category": (context) => const CategoriesPage(),
        },
      ),
    );
  }
}

