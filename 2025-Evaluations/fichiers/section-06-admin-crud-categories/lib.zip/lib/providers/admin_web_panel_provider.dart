import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:ecommerce_admin_web_panel/view_model/category_view_model.dart';
import 'package:flutter/cupertino.dart';

class AdminWenPanelProvider extends ChangeNotifier {

  List<QueryDocumentSnapshot> categoriesList = [];
  StreamSubscription<QuerySnapshot>? categoryStreamSubscription;
  CategoryViewModel categoryViewModel = CategoryViewModel();

  int totalCategoriesNum = 0;

  AdminWenPanelProvider() {
    getCategories();
  }

  getCategories() {
    categoryStreamSubscription?.cancel();

    categoryStreamSubscription = categoryViewModel.fetchCategories().listen((snapshot) {
      categoriesList = snapshot.docs;
      totalCategoriesNum = snapshot.docs.length;
      notifyListeners();
    });
  }

}