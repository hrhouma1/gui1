import 'package:flutter/material.dart';


class UpdatePromoBannerPage extends StatefulWidget {
  const UpdatePromoBannerPage({super.key});

  @override
  State<UpdatePromoBannerPage> createState() => _UpdatePromoBannerPageState();
}

class _UpdatePromoBannerPageState extends State<UpdatePromoBannerPage> {

  bool initialized = false;
  bool promoPage = true;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((c) {
      if(!initialized) {
        final args = ModalRoute.of(context)?.settings.arguments;

        if(args != null && args is Map<String, dynamic>) {
          promoPage = args['promo'] ?? true;
        }

        initialized = true;
        setState(() {

        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          promoPage
          ? "Update Promo"
          : "Update Banner"
        ),
        centerTitle: true,
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
        elevation: 4,
        shadowColor: Colors.deepPurple.shade200,
        titleSpacing: 20,
      ),
    );
  }
}
