import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:ecommerce_admin_web_panel/view_model/category_view_model.dart';
import 'package:ecommerce_admin_web_panel/view_model/product_view_model.dart';
import 'package:flutter/cupertino.dart';

class AdminWenPanelProvider extends ChangeNotifier {

  List<QueryDocumentSnapshot> categoriesList = [];
  StreamSubscription<QuerySnapshot>? categoryStreamSubscription;
  CategoryViewModel categoryViewModel = CategoryViewModel();

  List<QueryDocumentSnapshot> productsList = [];
  StreamSubscription<QuerySnapshot>? productsStreamSubscription;
  ProductViewModel productViewModel = ProductViewModel();

  int totalCategoriesNum = 0;
  int totalProductsNum = 0;

  AdminWenPanelProvider() {
    getCategories();
    getProducts();
  }

  getProducts() {
    productsStreamSubscription?.cancel();
    productsStreamSubscription = productViewModel.fetchProducts().listen((snapshot) {
      productsList = snapshot.docs;
      totalProductsNum = snapshot.docs.length;
      notifyListeners();
    });
  }

  getCategories() {
    categoryStreamSubscription?.cancel();

    categoryStreamSubscription = categoryViewModel.fetchCategories().listen((snapshot) {
      categoriesList = snapshot.docs;
      totalCategoriesNum = snapshot.docs.length;
      notifyListeners();
    });
  }

}