import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:provider/provider.dart';
import 'package:snap_shop_ecommerce_app/providers/cart_provider.dart';
import 'package:snap_shop_ecommerce_app/providers/user_provider.dart';
import 'package:snap_shop_ecommerce_app/views/auth/check_user_status.dart';
import 'package:snap_shop_ecommerce_app/views/auth/create_account_page.dart';
import 'package:snap_shop_ecommerce_app/views/auth/login_page.dart';
import 'package:snap_shop_ecommerce_app/views/bottonNav/home_page.dart';
import 'package:snap_shop_ecommerce_app/views/bottonNav/navPages/cart_page.dart';
import 'package:snap_shop_ecommerce_app/views/bottonNav/navPages/profile/edit_profile_page.dart';
import 'package:snap_shop_ecommerce_app/views/checkout/checkout_page.dart';
import 'package:snap_shop_ecommerce_app/views/coupons/coupons_page.dart';
import 'package:snap_shop_ecommerce_app/views/products/product_details_page.dart';
import 'package:snap_shop_ecommerce_app/views/products/show_products_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await dotenv.load(fileName: ".env");

  await Firebase.initializeApp();

  Stripe.publishableKey = dotenv.env["STRIPE_PUBLISH_KEY"]!;
  await Stripe.instance.applySettings();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => UserProvider(),
        ),
        ChangeNotifierProvider(
          create: (context) => CartProvider(),
        ),
      ],
      child: MaterialApp(
        title: 'Snap & Shop eCommerce App',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          fontFamily: 'Couture',
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.green),
          useMaterial3: true,
        ),
        routes: {
          "/": (context) => CheckUserStatus(),
          "/login": (context) => LoginPage(),
          "/signup": (context) => CreateAccountPage(),
          "/home": (context) => HomePage(),
          "/show_specific_products": (context) => ShowProductsPage(),
          "/product_details": (context) => ProductDetailsPage(),
          "/coupons": (context) => CouponsPage(),
          "/cart": (context) => CartPage(),
          "/checkout": (context) => CheckoutPage(),
          "/edit_profile": (context) => EditProfilePage(),
        },
      ),
    );
  }
}

