import 'package:flutter/material.dart';


class PromosBannersPage extends StatefulWidget {
  const PromosBannersPage({super.key});

  @override
  State<PromosBannersPage> createState() => _PromosBannersPageState();
}

class _PromosBannersPageState extends State<PromosBannersPage> {

  bool initialized = false;
  bool promoPage = true;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((c) {
      if(!initialized) {
        final args = ModalRoute.of(context)?.settings.arguments;

        if(args != null && args is Map<String, dynamic>) {
          promoPage = args['promo'] ?? true;
        }

        initialized = true;
        setState(() {

        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
        elevation: 4,
        shadowColor: Colors.deepPurple.shade200,
        titleSpacing: 20,
        title: Text(promoPage ? "Promos" : "Banners"),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
        onPressed: () {
          Navigator.pushNamed(context, "/update_promo_banner", arguments: {"promo": promoPage},);
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
